from django.contrib import admin

# Register your models here.
from .models import person
admin.site.register(person)
