from django.shortcuts import render

def service(request):
    return render(request, 'service/service.html')
def service_page(request):
    return render(request, 'service/service.html')